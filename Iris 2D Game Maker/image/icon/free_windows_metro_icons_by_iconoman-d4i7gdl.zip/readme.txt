Free Windows Metro Icons

License: License CC Attribution 3.0 Unported

This icon set offer developers a quick and easy way to create
stunning navigation bars, toolbars, and tab bars in their apps. 

Technically, developers receive unique 48x48 PNG images 
in black and white versions.


If you have any questions regarding copyright or licensing,
including whether another license is required for icon use
within products, please contact us here: www.aha-soft.com/support.htm 

Product page:
http://www.iconsforwindows8.com/free-windows-metro-icons/

Download:
http://www.iconsforwindows8.com/downloads/free-windows-metro-icons.zip
http://www.icon-files.com/downloads/free-windows-metro-icons.zip


More stock icons:
http://www.aha-soft.com/iconsets.htm

More icons for Windows 8 and Windows Phone:
http://www.iconsforwindows8.com/


Icon Design Service

We can design custom icons for you. Please find the basic information
about ordering icons, pricing and the portfolio here:
http://www.aha-soft.com/customdev/design.htm


Support page: http://www.aha-soft.com/support.htm

Copyright � 2000-2011 Aha-Soft. All rights reserved. 